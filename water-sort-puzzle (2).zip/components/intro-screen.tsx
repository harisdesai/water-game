"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

interface IntroScreenProps {
  onStart: () => void
}

export function IntroScreen({ onStart }: IntroScreenProps) {
  const [showButton, setShowButton] = useState(false)
  const [tubeAnimations, setTubeAnimations] = useState<
    {
      height: number
      color: string
      delay: number
    }[]
  >([])

  useEffect(() => {
    // Create tube animations
    const animations = [
      { height: 60, color: "bg-red-500", delay: 0.2 },
      { height: 40, color: "bg-blue-500", delay: 0.4 },
      { height: 80, color: "bg-green-500", delay: 0.6 },
      { height: 50, color: "bg-purple-500", delay: 0.8 },
    ]
    setTubeAnimations(animations)

    // Show the play button after animations
    const timer = setTimeout(() => setShowButton(true), 2000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b from-blue-600 to-purple-800"
    >
      <div className="relative mb-8">
        {/* Animated tubes */}
        <div className="flex gap-4 mb-8">
          {tubeAnimations.map((tube, i) => (
            <motion.div
              key={i}
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{
                delay: i * 0.2,
                duration: 0.8,
                type: "spring",
                stiffness: 100,
              }}
              className="relative w-12 h-48 rounded-b-3xl overflow-hidden border-2 border-white/30 bg-white/20 backdrop-blur-md"
            >
              {/* Water animations */}
              <motion.div
                initial={{ height: "0%" }}
                animate={{
                  height: ["0%", `${tube.height}%`, `${tube.height - 20}%`, `${tube.height - 10}%`],
                  y: [0, 0, 5, 0],
                }}
                transition={{
                  delay: tube.delay,
                  duration: 2,
                  times: [0, 0.6, 0.8, 1],
                  ease: "easeInOut",
                }}
                className={`absolute bottom-0 left-0 w-full ${tube.color} rounded-t-sm`}
              >
                {/* Water surface */}
                <motion.div
                  className="absolute top-0 inset-x-0 h-1 bg-white/30 rounded-full transform -translate-y-1/2"
                  animate={{
                    scaleX: [1, 1.05, 1],
                    opacity: [0.3, 0.4, 0.3],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                />

                {/* Bubbles */}
                {Array.from({ length: 3 }).map((_, j) => (
                  <motion.div
                    key={j}
                    className="absolute w-1.5 h-1.5 rounded-full bg-white/40"
                    style={{
                      left: `${Math.random() * 80 + 10}%`,
                      bottom: `${Math.random() * 50}%`,
                    }}
                    animate={{
                      y: [0, -20],
                      opacity: [0.4, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Number.POSITIVE_INFINITY,
                      repeatDelay: Math.random() * 3,
                    }}
                  />
                ))}
              </motion.div>
              {/* Glass reflection */}
              <div className="absolute top-0 left-1 w-2 h-full bg-white/20 rounded-full" />
            </motion.div>
          ))}
        </div>

        {/* Animated pouring effect */}
        <motion.div
          className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-full"
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: [-100, 0, -100], opacity: [0, 1, 0] }}
          transition={{ delay: 1, duration: 2, times: [0, 0.5, 1] }}
        >
          {Array.from({ length: 10 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-3 h-5"
              style={{
                left: `${Math.random() * 20 - 10}px`,
                top: `${i * 5}px`,
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.8, 0], y: [0, 30] }}
              transition={{
                delay: 1 + i * 0.05,
                duration: 0.5,
                ease: "easeIn",
              }}
            >
              <svg width="12" height="20" viewBox="0 0 12 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M6 0C6 0 0 8 0 12C0 16.4183 2.68629 20 6 20C9.31371 20 12 16.4183 12 12C12 8 6 0 6 0Z"
                  fill="rgba(59, 130, 246, 0.8)"
                />
              </svg>
            </motion.div>
          ))}
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="text-5xl font-bold text-center text-white mb-4 tracking-tight"
          style={{ textShadow: "0 2px 10px rgba(0,0,0,0.2)" }}
        >
          Water Sort
          <span className="block text-6xl bg-clip-text text-transparent bg-gradient-to-r from-blue-300 to-purple-300">
            Puzzle
          </span>
        </motion.h1>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="text-blue-100 text-center text-lg mb-8"
        >
          Sort the colored water and test your puzzle skills
        </motion.p>

        {/* Play button */}
        {showButton && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="flex justify-center"
          >
            <Button
              onClick={onStart}
              size="lg"
              className="bg-gradient-to-r from-blue-400 to-purple-500 hover:from-blue-500 hover:to-purple-600 text-white px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
            >
              <Play className="mr-2 h-5 w-5" />
              Play Now
            </Button>
          </motion.div>
        )}
      </div>

      {/* Floating bubbles */}
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={i}
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            scale: Math.random() * 0.5 + 0.5,
          }}
          animate={{
            y: [null, Math.random() * -200 - 100],
            x: [null, Math.random() * 100 - 50],
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "loop",
          }}
          className="absolute rounded-full bg-white/10 backdrop-blur-sm"
          style={{
            width: `${Math.random() * 30 + 10}px`,
            height: `${Math.random() * 30 + 10}px`,
          }}
        />
      ))}
    </motion.div>
  )
}

