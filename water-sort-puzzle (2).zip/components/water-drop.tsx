"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface WaterDropProps {
  fromPos: { x: number; y: number }
  toPos: { x: number; y: number }
  color: string
  delay: number
}

export function WaterDrop({ fromPos, toPos, color, delay }: WaterDropProps) {
  const [path, setPath] = useState<{ x: number; y: number }[]>([])

  // Generate a curved path for the water drop
  useEffect(() => {
    const midX = (fromPos.x + toPos.x) / 2
    // Create more natural arc with higher control point
    const controlPointX = midX + (Math.random() * 40 - 20)
    const controlPointY = Math.min(fromPos.y, toPos.y) - Math.random() * 30 - 20 // Higher control point

    // Create points along a quadratic bezier curve
    const points = []
    for (let t = 0; t <= 1; t += 0.05) {
      const x = (1 - t) * (1 - t) * fromPos.x + 2 * (1 - t) * t * controlPointX + t * t * toPos.x
      const y = (1 - t) * (1 - t) * fromPos.y + 2 * (1 - t) * t * controlPointY + t * t * toPos.y
      points.push({ x, y })
    }

    setPath(points)
  }, [fromPos, toPos])

  if (path.length === 0) return null

  return (
    <motion.div
      className="fixed top-0 left-0 z-50 pointer-events-none"
      initial={{
        x: fromPos.x,
        y: fromPos.y,
        opacity: 0,
        scale: 0.5,
        rotate: Math.random() * 30 - 15, // Random initial rotation
      }}
      animate={{
        x: path.map((p) => p.x),
        y: path.map((p) => p.y),
        opacity: [0, 1, 1, 0],
        scale: [0.5, 1, 1, 0.5],
        rotate: [Math.random() * 30 - 15, Math.random() * 60 - 30, Math.random() * 30 - 15], // Dynamic rotation during flight
      }}
      transition={{
        duration: 0.8,
        delay,
        times: [0, 0.1, 0.9, 1],
        ease: "easeOut",
      }}
    >
      <div
        className="relative w-4 h-6 transform -translate-x-1/2 -translate-y-1/2"
        style={{
          filter: "drop-shadow(0 2px 3px rgba(0,0,0,0.2))",
        }}
      >
        {/* Water drop shape */}
        <svg width="16" height="24" viewBox="0 0 16 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M8 0C8 0 0 10 0 16C0 20.4183 3.58172 24 8 24C12.4183 24 16 20.4183 16 16C16 10 8 0 8 0Z"
            fill={`rgba(${color}, 0.9)`}
          />
        </svg>

        {/* Highlight */}
        <div className="absolute top-1/4 left-1/4 w-1/2 h-1/3 bg-white/40 rounded-full transform rotate-45" />
      </div>
    </motion.div>
  )
}

