"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Tube } from "./tube"
import { Button } from "@/components/ui/button"
import { RefreshCw, Undo, Award, Volume2, VolumeX, HelpCircle, Settings } from "lucide-react"
import confetti from "canvas-confetti"
import { IntroScreen } from "./intro-screen"
import { WaterDrop } from "./water-drop"

// Define color palette for water segments with gradient pairs
const COLORS = [
  { base: "bg-red-500", light: "bg-red-400", dark: "bg-red-600", rgb: "239, 68, 68" },
  { base: "bg-blue-500", light: "bg-blue-400", dark: "bg-blue-600", rgb: "59, 130, 246" },
  { base: "bg-green-500", light: "bg-green-400", dark: "bg-green-600", rgb: "34, 197, 94" },
  { base: "bg-yellow-500", light: "bg-yellow-400", dark: "bg-yellow-600", rgb: "234, 179, 8" },
  { base: "bg-purple-500", light: "bg-purple-400", dark: "bg-purple-600", rgb: "168, 85, 247" },
  { base: "bg-pink-500", light: "bg-pink-400", dark: "bg-pink-600", rgb: "236, 72, 153" },
  { base: "bg-orange-500", light: "bg-orange-400", dark: "bg-orange-600", rgb: "249, 115, 22" },
  { base: "bg-teal-500", light: "bg-teal-400", dark: "bg-teal-600", rgb: "20, 184, 166" },
]

// Number of segments in each tube
const SEGMENTS_PER_TUBE = 4

// Generate a random level
const generateLevel = (numTubes: number, numColors: number) => {
  // Create empty tubes
  const tubes: string[][] = Array(numTubes)
    .fill(null)
    .map(() => [])

  // Fill tubes with random colors
  const totalSegments = (numTubes - 2) * SEGMENTS_PER_TUBE
  const segmentsPerColor = totalSegments / numColors

  // Create an array with all color segments
  let allSegments: string[] = []
  for (let i = 0; i < numColors; i++) {
    for (let j = 0; j < segmentsPerColor; j++) {
      allSegments.push(COLORS[i].base)
    }
  }

  // Shuffle the segments
  allSegments = allSegments.sort(() => Math.random() - 0.5)

  // Distribute segments to tubes
  for (let i = 0; i < numTubes - 2; i++) {
    tubes[i] = allSegments.slice(i * SEGMENTS_PER_TUBE, (i + 1) * SEGMENTS_PER_TUBE)
  }

  return tubes
}

// Check if the game is complete
const isGameComplete = (tubes: string[][]) => {
  return tubes.every(
    (tube) => tube.length === 0 || (tube.length === SEGMENTS_PER_TUBE && tube.every((segment) => segment === tube[0])),
  )
}

// Check if a pour is valid
const isValidPour = (fromTube: string[], toTube: string[]) => {
  if (fromTube.length === 0) return false
  if (toTube.length === SEGMENTS_PER_TUBE) return false

  const topColorFrom = fromTube[fromTube.length - 1]

  // If destination tube is empty, pour is valid
  if (toTube.length === 0) return true

  // If top colors match, pour is valid
  const topColorTo = toTube[toTube.length - 1]
  return topColorFrom === topColorTo
}

// Count consecutive same colors at the top of the tube
const countConsecutiveColors = (tube: string[]) => {
  if (tube.length === 0) return 0

  const topColor = tube[tube.length - 1]
  let count = 0

  for (let i = tube.length - 1; i >= 0; i--) {
    if (tube[i] === topColor) {
      count++
    } else {
      break
    }
  }

  return count
}

// Get RGB values from color name
const getRgbFromColor = (color: string) => {
  const colorObj = COLORS.find((c) => c.base === color)
  return colorObj ? colorObj.rgb : "255, 255, 255"
}

export default function WaterSortPuzzle() {
  const [tubes, setTubes] = useState<string[][]>([])
  const [selectedTubeIndex, setSelectedTubeIndex] = useState<number | null>(null)
  const [moves, setMoves] = useState(0)
  const [gameComplete, setGameComplete] = useState(false)
  const [isPouring, setIsPouring] = useState(false)
  const [moveHistory, setMoveHistory] = useState<string[][][]>([])
  const [level, setLevel] = useState(1)
  const [showIntro, setShowIntro] = useState(true)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [showTutorial, setShowTutorial] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [bestMoves, setBestMoves] = useState<Record<number, number>>({})
  const [waterDrops, setWaterDrops] = useState<
    {
      id: number
      fromPos: { x: number; y: number }
      toPos: { x: number; y: number }
      color: string
      delay: number
    }[]
  >([])
  const [nextDropId, setNextDropId] = useState(0)
  const [pouringTubes, setPouringTubes] = useState<{
    fromIndex: number
    toIndex: number
  } | null>(null)

  // Refs for tube elements
  const tubeRefs = useRef<(HTMLDivElement | null)[]>([])

  // Sound effects
  const pourSoundRef = useRef<HTMLAudioElement | null>(null)
  const completeSoundRef = useRef<HTMLAudioElement | null>(null)
  const selectSoundRef = useRef<HTMLAudioElement | null>(null)
  const successSoundRef = useRef<HTMLAudioElement | null>(null)

  // Initialize sounds
  useEffect(() => {
    pourSoundRef.current = new Audio("/placeholder.svg?height=1&width=1") // Replace with actual sound URL
    completeSoundRef.current = new Audio("/placeholder.svg?height=1&width=1") // Replace with actual sound URL
    selectSoundRef.current = new Audio("/placeholder.svg?height=1&width=1") // Replace with actual sound URL
    successSoundRef.current = new Audio("/placeholder.svg?height=1&width=1") // Replace with actual sound URL

    // Preload sounds
    pourSoundRef.current.load()
    completeSoundRef.current.load()
    selectSoundRef.current.load()
    successSoundRef.current.load()

    return () => {
      pourSoundRef.current = null
      completeSoundRef.current = null
      selectSoundRef.current = null
      successSoundRef.current = null
    }
  }, [])

  // Load best moves from localStorage
  useEffect(() => {
    const savedBestMoves = localStorage.getItem("waterSortBestMoves")
    if (savedBestMoves) {
      setBestMoves(JSON.parse(savedBestMoves))
    }
  }, [])

  // Save best moves to localStorage
  useEffect(() => {
    if (gameComplete && (!bestMoves[level] || moves < bestMoves[level])) {
      const newBestMoves = { ...bestMoves, [level]: moves }
      setBestMoves(newBestMoves)
      localStorage.setItem("waterSortBestMoves", JSON.stringify(newBestMoves))
    }
  }, [gameComplete, moves, level, bestMoves])

  // Play sound helper
  const playSound = (sound: HTMLAudioElement | null) => {
    if (sound && soundEnabled) {
      sound.currentTime = 0
      sound.play().catch((e) => console.log("Error playing sound:", e))
    }
  }

  // Initialize the game
  useEffect(() => {
    if (!showIntro) {
      startNewGame()
    }
  }, [level, showIntro])

  // Check for game completion
  useEffect(() => {
    if (tubes.length > 0 && isGameComplete(tubes) && !gameComplete) {
      setGameComplete(true)

      // Play completion sound
      playSound(successSoundRef.current)

      // Trigger confetti effect
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.6 },
        colors: ["#ff0000", "#00ff00", "#0000ff", "#ffff00", "#ff00ff", "#00ffff"],
      })
    }
  }, [tubes, gameComplete])

  const startNewGame = () => {
    const numTubes = Math.min(5 + Math.floor(level / 2), 10) // Increase tubes with level, max 10
    const numColors = numTubes - 2
    const newTubes = generateLevel(numTubes, numColors)
    setTubes(newTubes)
    setSelectedTubeIndex(null)
    setMoves(0)
    setGameComplete(false)
    setMoveHistory([])
    setPouringTubes(null)
    // Reset tube refs array
    tubeRefs.current = Array(numTubes).fill(null)
  }

  const handleTubeClick = (index: number) => {
    if (isPouring || gameComplete) return

    if (selectedTubeIndex === null) {
      // Select tube
      setSelectedTubeIndex(index)
      playSound(selectSoundRef.current)
    } else if (selectedTubeIndex === index) {
      // Deselect tube
      setSelectedTubeIndex(null)
    } else {
      // Try to pour from selected tube to this tube
      const fromTube = [...tubes[selectedTubeIndex]]
      const toTube = [...tubes[index]]

      if (isValidPour(fromTube, toTube)) {
        // Save current state to history
        setMoveHistory([...moveHistory, JSON.parse(JSON.stringify(tubes))])

        // Perform the pour
        setIsPouring(true)
        playSound(pourSoundRef.current)

        // Calculate how many segments to pour (consecutive same colors)
        const count = countConsecutiveColors(fromTube)
        const topColor = fromTube[fromTube.length - 1]

        // Set pouring tubes for animation
        setPouringTubes({
          fromIndex: selectedTubeIndex,
          toIndex: index,
        })

        // Get tube element positions for animation
        const fromTubeEl = tubeRefs.current[selectedTubeIndex]
        const toTubeEl = tubeRefs.current[index]

        if (fromTubeEl && toTubeEl) {
          const fromRect = fromTubeEl.getBoundingClientRect()
          const toRect = toTubeEl.getBoundingClientRect()

          // Wait for tube tilt animation to start before creating water drops
          setTimeout(() => {
            // Create water drops for animation - more drops for a more fluid effect
            const newDrops = []

            // Calculate exact positions for top layer transfer
            const sourceWaterTop = fromRect.top + 50 - fromTube.length * 14 + 5
            const destWaterTop = toRect.top + 50 - toTube.length * 14 + 5

            // Create more drops with varied positions for a more realistic pour
            for (let i = 0; i < 25; i++) {
              // Add slight randomness to drop positions for natural look
              const randomOffsetX = Math.random() * 6 - 3
              const randomOffsetY = Math.random() * 4 - 2

              newDrops.push({
                id: nextDropId + i,
                fromPos: {
                  x: fromRect.left + fromRect.width / 2 + randomOffsetX,
                  y: sourceWaterTop + randomOffsetY,
                },
                toPos: {
                  x: toRect.left + toRect.width / 2 + randomOffsetX,
                  y: destWaterTop + randomOffsetY,
                },
                color: topColor,
                delay: i * 0.03, // Faster drops for more fluid motion
              })
            }

            setWaterDrops(newDrops)
            setNextDropId(nextDropId + 25)
          }, 300)
        }

        // Create new tubes array with the pour
        const newTubes = [...tubes]

        // Remove segments from source tube
        newTubes[selectedTubeIndex] = newTubes[selectedTubeIndex].slice(0, -count)

        // Add segments to destination tube with delay
        setTimeout(() => {
          setTubes((prevTubes) => {
            const updatedTubes = [...prevTubes]
            for (let i = 0; i < count; i++) {
              updatedTubes[index] = [...updatedTubes[index], topColor]
            }
            return updatedTubes
          })

          // Reset pouring tubes
          setTimeout(() => {
            setPouringTubes(null)
          }, 300)

          // Reset selection and increment moves after animation
          setTimeout(() => {
            setSelectedTubeIndex(null)
            setMoves(moves + 1)
            setIsPouring(false)
            setWaterDrops([])
          }, 600)
        }, 1000) // Wait for animation to complete

        // Update source tube immediately
        setTubes(newTubes)
      } else {
        // Invalid move, just deselect
        setSelectedTubeIndex(null)
      }
    }
  }

  const undoMove = () => {
    if (moveHistory.length > 0) {
      const previousState = moveHistory[moveHistory.length - 1]
      setTubes(previousState)
      setMoveHistory(moveHistory.slice(0, -1))
      setMoves(moves + 1) // Count undo as a move
      setSelectedTubeIndex(null)
    }
  }

  const nextLevel = () => {
    setLevel(level + 1)
  }

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled)
  }

  if (showIntro) {
    return <IntroScreen onStart={() => setShowIntro(false)} />
  }

  return (
    <div className="flex flex-col items-center w-full">
      {/* Background particles */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-blue-500/5"
            style={{
              width: `${Math.random() * 50 + 10}px`,
              height: `${Math.random() * 50 + 10}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, Math.random() * 100 - 50],
              x: [0, Math.random() * 100 - 50],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              duration: Math.random() * 20 + 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        ))}
      </div>

      <div className="w-full max-w-4xl">
        <div className="flex justify-between items-center w-full mb-8">
          <h1 className="text-3xl font-bold text-blue-800">Water Sort Puzzle</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={toggleSound} className="bg-white/80 shadow-md">
              {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowSettings(true)}
              className="bg-white/80 shadow-md"
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowTutorial(true)}
              className="bg-white/80 shadow-md"
            >
              <HelpCircle className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex justify-between w-full mb-6 bg-white/50 backdrop-blur-sm p-4 rounded-xl shadow-md">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={startNewGame}
              className="bg-white shadow-md hover:bg-blue-50"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={undoMove}
              disabled={moveHistory.length === 0 || isPouring}
              className="bg-white shadow-md hover:bg-blue-50"
            >
              <Undo className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-4">
            <div className="flex flex-col items-center justify-center bg-white px-6 py-2 rounded-lg shadow-md">
              <span className="text-sm text-gray-500">Level</span>
              <span className="font-bold text-blue-800 text-xl">{level}</span>
            </div>
            <div className="flex flex-col items-center justify-center bg-white px-6 py-2 rounded-lg shadow-md">
              <span className="text-sm text-gray-500">Moves</span>
              <span className="font-bold text-blue-800 text-xl">{moves}</span>
              {bestMoves[level] && <span className="text-xs text-gray-500">Best: {bestMoves[level]}</span>}
            </div>
          </div>
        </div>

        <motion.div
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-8 p-6 bg-white/30 backdrop-blur-sm rounded-xl shadow-lg relative"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {tubes.map((tube, index) => (
            <div key={index} ref={(el) => (tubeRefs.current[index] = el)}>
              <Tube
                segments={tube}
                isSelected={selectedTubeIndex === index}
                onClick={() => handleTubeClick(index)}
                isPouringFrom={pouringTubes?.fromIndex === index}
                isPouringTo={pouringTubes?.toIndex === index}
                pouringToIndex={pouringTubes?.toIndex}
                tubeIndex={index}
              />
            </div>
          ))}

          {/* Water drops animation */}
          {waterDrops.map((drop) => (
            <WaterDrop
              key={drop.id}
              fromPos={drop.fromPos}
              toPos={drop.toPos}
              color={getRgbFromColor(drop.color)}
              delay={drop.delay}
            />
          ))}
        </motion.div>
      </div>

      <AnimatePresence>
        {gameComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50"
          >
            <div className="bg-white rounded-xl p-8 shadow-2xl flex flex-col items-center max-w-sm mx-4">
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: [0.5, 1.2, 1], opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Award className="w-20 h-20 text-yellow-500 mb-4" />
              </motion.div>
              <h2 className="text-3xl font-bold text-blue-800 mb-2">Level Complete!</h2>
              <p className="text-gray-600 mb-2 text-center">
                You completed level {level} in {moves} moves!
              </p>
              {bestMoves[level] && bestMoves[level] === moves && (
                <p className="text-green-600 font-bold mb-6">New Best Score!</p>
              )}
              {bestMoves[level] && bestMoves[level] !== moves && (
                <p className="text-gray-500 mb-6">Best: {bestMoves[level]} moves</p>
              )}
              <div className="flex gap-4">
                <Button variant="outline" onClick={startNewGame} className="px-6">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Replay
                </Button>
                <Button onClick={nextLevel} className="bg-gradient-to-r from-blue-500 to-purple-600 px-6">
                  Next Level
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {showTutorial && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50"
          >
            <div className="bg-white rounded-xl p-8 shadow-2xl max-w-md mx-4">
              <h2 className="text-2xl font-bold text-blue-800 mb-4">How to Play</h2>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-2">
                  <div className="bg-blue-100 p-1 rounded-full mt-1">
                    <span className="block w-4 h-4 bg-blue-500 rounded-full"></span>
                  </div>
                  <p>Click on a tube to select it.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-blue-100 p-1 rounded-full mt-1">
                    <span className="block w-4 h-4 bg-blue-500 rounded-full"></span>
                  </div>
                  <p>Click on another tube to pour water from the selected tube.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-blue-100 p-1 rounded-full mt-1">
                    <span className="block w-4 h-4 bg-blue-500 rounded-full"></span>
                  </div>
                  <p>You can only pour water if the colors match or if the destination tube is empty.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-blue-100 p-1 rounded-full mt-1">
                    <span className="block w-4 h-4 bg-blue-500 rounded-full"></span>
                  </div>
                  <p>The goal is to sort all water so each tube contains only one color or is empty.</p>
                </li>
              </ul>
              <div className="flex justify-center">
                <Button onClick={() => setShowTutorial(false)}>Got it!</Button>
              </div>
            </div>
          </motion.div>
        )}

        {showSettings && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50"
          >
            <div className="bg-white rounded-xl p-8 shadow-2xl max-w-md mx-4">
              <h2 className="text-2xl font-bold text-blue-800 mb-4">Settings</h2>

              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-between">
                  <span>Sound Effects</span>
                  <Button variant={soundEnabled ? "default" : "outline"} onClick={toggleSound} size="sm">
                    {soundEnabled ? "On" : "Off"}
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <span>Current Level</span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => level > 1 && setLevel(level - 1)}
                      disabled={level <= 1}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{level}</span>
                    <Button variant="outline" size="sm" onClick={() => setLevel(level + 1)}>
                      +
                    </Button>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h3 className="font-semibold mb-2">Best Scores</h3>
                  <div className="max-h-40 overflow-y-auto">
                    {Object.entries(bestMoves).length > 0 ? (
                      Object.entries(bestMoves)
                        .sort(([a], [b]) => Number.parseInt(a) - Number.parseInt(b))
                        .map(([lvl, score]) => (
                          <div key={lvl} className="flex justify-between py-1">
                            <span>Level {lvl}</span>
                            <span className="font-medium">{score} moves</span>
                          </div>
                        ))
                    ) : (
                      <p className="text-gray-500 text-sm">No scores yet. Complete levels to see your best scores!</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => {
                    localStorage.removeItem("waterSortBestMoves")
                    setBestMoves({})
                  }}
                >
                  Reset Scores
                </Button>
                <Button onClick={() => setShowSettings(false)}>Close</Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

