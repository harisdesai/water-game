"use client"

import WaterSortPuzzle from "../components/water-sort-puzzle"

export default function SyntheticV0PageForDeployment() {
  return <WaterSortPuzzle />
}